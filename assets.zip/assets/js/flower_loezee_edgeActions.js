
(function($,Edge,compId){var Composition=Edge.Composition,Symbol=Edge.Symbol;
//Edge symbol: 'stage'
(function(symbolName){Symbol.bindElementAction(compId,symbolName,"document","compositionReady",function(sym,e){var info=['Reliable','Tenacious','Innovative','Supportive','Multi-Facited','Focused','Calm'];function useButtons(element,i){sym.$(element).bind("mouseover",function(){sym.$(element).css({"background-image":"url('assets/img/animation/"+element+"_purple.png')"});});sym.$(element).bind("mouseleave",function(){sym.$(element).css({"background-image":"url('assets/img/animation/"+element+".png')"});});sym.$(element).bind("click",function(){sym.play(0);sym.$("info").append("<div>"+info[i]+"</div>");console.log(info[i]);sym.$("image").css({"background-image":"url('assets/img/animation/"+element+"_purple.png')","background-repeat":"no-repeat",});console.log(element);sym.$(element).css({"display":"none"});sym.$(element).bind("mouseleave",function(){sym.$(element).css({"display":"none"});});sym.$(element).bind("mouseover",function(){sym.$(element).css({"display":"none"});});});}
['petal1','petal2','petal3','petal4','petal5','petal6','petal7'].forEach(useButtons);});
//Edge binding end
Symbol.bindTriggerAction(compId,symbolName,"Default Timeline",0,function(sym,e){});
//Edge binding end
})("stage");
//Edge symbol end:'stage'

//=========================================================

//Edge symbol: 'Symbol_1'
(function(symbolName){})("Symbol_2");
//Edge symbol end:'Symbol_2'

//=========================================================

//Edge symbol: 'Symbol_2'
(function(symbolName){})("Symbol_1");
//Edge symbol end:'Symbol_1'
})(jQuery,AdobeEdge,"EDGE-11104451");
